# load libraries
library(tidyverse)

# read data in
intense_data <- read_tsv("https://raw.githubusercontent.com/picoral/PREDICAR-2022/main/intensifiers_tweets.tsv")

# run linear regression
# what is the effect of account on intensification?
model_1 <- lm(intensifier ~ account + gender + number,
              data = intense_data)

summary(model_1)

anova(model_1)

library(effects)
library(scales)
effect("account", model_1) %>%
  data.frame() %>%
  ggplot(aes(x = reorder(account, fit),
             y = fit,
             ymin = lower,
             ymax = upper)) +
  geom_errorbar() +
  geom_label(aes(label = format(fit*100, digits = 2))) +
  theme_linedraw() +
  labs(y = "percentual intensificado",
       x = "",
       title = "Percentual de adjetivos intensificados por conta no Twitter") +
  scale_y_continuous(labels = percent_format())


effect("gender", model_1) %>%
  data.frame() %>%
  filter(gender != "Unsp") %>%
  ggplot(aes(x = reorder(gender, fit),
             y = fit,
             ymin = lower,
             ymax = upper)) +
  geom_errorbar() +
  geom_label(aes(label = format(fit, digits = 2))) +
  theme_linedraw() +
  labs(y = "percentual intensificado",
       x = "",
       title = "Percentual de adjetivos intensificados por gênero do adjetivo",
       caption = "gênero não especificado foi removido da visualização")


effect("number", model_1) %>%
  data.frame() %>%
  ggplot(aes(x = reorder(number, fit),
             y = fit,
             ymin = lower,
             ymax = upper)) +
  geom_errorbar() +
  geom_label(aes(label = format(fit, digits = 2))) +
  theme_linedraw() +
  labs(y = "percentual intensificado",
       x = "",
       title = "Percentual de adjetivos intensificados por número do adjetivo")

# logistic regression
model_2 <- glm(intensifier ~ account + gender + number,
               data = intense_data,
               family = "binomial")

summary(model_2)

effect("account", model_2) %>%
  data.frame() %>%
  ggplot(aes(x = reorder(account, fit),
             y = fit,
             ymin = lower,
             ymax = upper)) +
  geom_errorbar() +
  geom_point()

# Varbrul, Goldvarb -- Rbrul
# mixed effect models
library(lme4)
modelo_mixed_effect <- glmer()


